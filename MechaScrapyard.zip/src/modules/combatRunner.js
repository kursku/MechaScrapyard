import { rollD100, rollBonusPool, resolveBonusDice } from '@/util/dice';
import Log from '@/log';
import Events from '@/events';
import * as CombatUtils from './combat';

// ─── Stance Definitions (§4.3) ───────────────────────────────────────────────
export const STANCES = {
    offensive: {
        id: 'offensive',
        name: 'Offensive',
        desc: 'Focus on maximum damage. Defense compromised.',
        icon: '⚔',
        atkMod: 0.15,
        defMod: -0.10,
        heatDissipMod: 0,
    },
    balanced: {
        id: 'balanced',
        name: 'Balanced',
        desc: 'No modifiers. Standard.',
        icon: '⚖',
        atkMod: 0,
        defMod: 0,
        heatDissipMod: 0,
    },
    defensive: {
        id: 'defensive',
        name: 'Defensive',
        desc: 'Prioritizes survival. Reduced damage.',
        icon: '🛡',
        atkMod: -0.10,
        defMod: 0.15,
        heatDissipMod: 0,
    },
    cautious: {
        id: 'cautious',
        name: 'Cautious',
        desc: 'Prolongs combat, less risk, better Heat dissipation.',
        icon: '❄',
        atkMod: -0.20,
        defMod: 0.10,
        heatDissipMod: 0.25,
    },
};

// ─── Targeting Policy Definitions (§3.2) ─────────────────────────────────────
export const TARGETING_POLICIES = {
    auto: {
        id: 'auto',
        name: 'Auto',
        desc: 'Weighted standard distribution.',
        icon: '◎',
        weights: { torso: 40, left_arm: 20, right_arm: 20, legs: 20 },
    },
    aggressive: {
        id: 'aggressive',
        name: 'Aggressive',
        desc: 'Prioritizes Torso — quick kill, but risky.',
        icon: '☠',
        weights: { torso: 60, left_arm: 10, right_arm: 10, legs: 20 },
    },
    tactical: {
        id: 'tactical',
        name: 'Tactical',
        desc: 'Prioritizes Arms — disarm the enemy.',
        icon: '✂',
        weights: { torso: 10, left_arm: 35, right_arm: 35, legs: 20 },
    },
    defensive: {
        id: 'defensive',
        name: 'Defensive',
        desc: 'Prioritizes Legs — prevent escape and advance.',
        icon: '⊘',
        weights: { torso: 15, left_arm: 15, right_arm: 15, legs: 55 },
    },
};

// ─── Token Definitions (Sprint 2B) ───────────────────────────────────────────
export const TOKEN_DEFS = {
    BREACH: {
        id: 'BREACH',
        name: 'Breach',
        icon: '🔓',
        color: '#f55',
        desc: 'Compromised armor. +1 damage taken per stack.',
        maxStacks: 5,
    },
    BURN: {
        id: 'BURN',
        name: 'Burn',
        icon: '🔥',
        color: '#f80',
        desc: 'On fire. Start of turn: d6 per stack; 4+ = 1 damage.',
        maxStacks: 4,
    },
    ERROR: {
        id: 'ERROR',
        name: 'Error',
        icon: '⚡',
        color: '#ff0',
        desc: 'System unstable. 50% chance to lose turn & take Stress.',
        maxStacks: 3,
    },
    SLOW: {
        id: 'SLOW',
        name: 'Slow',
        icon: '🐢',
        color: '#88f',
        desc: 'Locomotion impaired. -10 Accuracy/Evasion per stack.',
        maxStacks: 3,
    },
    TARGET_LOCK: {
        id: 'TARGET_LOCK',
        name: 'Target Lock',
        icon: '🎯',
        color: '#f0f',
        desc: 'Target painted. Attacker gains +1 Bonus Die.',
        maxStacks: 1,
    },
    SUPPRESS: {
        id: 'SUPPRESS',
        name: 'Suppressed',
        icon: '🛡️',
        color: '#888',
        desc: 'Under fire. -1 Damage Dealt per stack.',
        maxStacks: 3,
    },
};

// ─── Weapon Constants (§3.3) ──────────────────────────────────────────────────
export const DICE_VALUES = {
    d4: { sides: 4, supplyPerUse: 0.33 },
    d6: { sides: 6, supplyPerUse: 0.5 },
    d8: { sides: 8, supplyPerUse: 1 },
    d10: { sides: 10, supplyPerUse: 2 },
    d12: { sides: 12, supplyPerUse: 3 },
};

export const CATEGORY_ATTR = {
    fight: 'mus', // Muscle -> melee
    short: 'ref', // Reflexes -> firearms
    long: 'foc',  // Focus -> artillery
};

// ─── Part display names for log ───────────────────────────────────────────────
const PART_NAMES = {
    torso: 'TORSO',
    left_arm: 'LEFT ARM',
    right_arm: 'RIGHT ARM',
    legs: 'LEGS',
};

/**
 * Weighted random part selection respecting destroyed parts.
 * @param {Object} targetFrame
 * @param {string} policyId
 * @returns {string} partId
 */
function selectTargetPartWeighted(targetFrame, policyId = 'auto') {
    const policy = TARGETING_POLICIES[policyId] || TARGETING_POLICIES.auto;
    const weights = policy.weights;

    // Filter out destroyed parts, redistribute weight
    const available = {};
    let totalWeight = 0;

    for (const [partId, weight] of Object.entries(weights)) {
        const part = targetFrame.parts[partId];
        if (part && part.status !== 'destroyed') {
            available[partId] = weight;
            totalWeight += weight;
        }
    }

    // All parts destroyed except torso fallback
    if (totalWeight === 0) return 'torso';

    // Weighted random selection
    let roll = Math.random() * totalWeight;
    for (const [partId, weight] of Object.entries(available)) {
        roll -= weight;
        if (roll <= 0) return partId;
    }

    return 'torso'; // fallback
}

/**
 * CombatRunner — manages the active combat encounter.
 * Follows the Runner pattern from the implementation plan.
 */
export default class CombatRunner {
    constructor(state) {
        this.state = state;

        // Active encounter state
        this.active = false;
        this.mission = null;
        this.enemies = [];
        this.turnNumber = 0;
        this.turnTimer = 0;
        this.combatLog = [];
        this.result = null;

        // Maneuver loadout
        this.equippedManeuvers = []; // IDs

        // Configuration (locked during combat)
        this.stance = 'balanced';
        this.targeting = 'auto';

        this.activeModifiers = { damageMult: 1, accuracyBonus: 0 };
    }

    // ─── Token Management (§8) ────────────────────────────────────────────────

    applyToken(frame, tokenType, stacks = 1) {
        const def = TOKEN_DEFS[tokenType];
        if (!def) return 0;

        if (!frame.tokens) frame.tokens = [];

        const existing = frame.tokens.find(t => t.type === tokenType);
        if (existing) {
            const before = existing.stacks;
            existing.stacks = Math.min(existing.stacks + stacks, def.maxStacks);
            return existing.stacks - before;
        }

        // Limit 6 different token types per unit
        if (frame.tokens.length >= 6) return 0;

        const applied = Math.min(stacks, def.maxStacks);
        frame.tokens.push({ type: tokenType, stacks: applied });
        return applied;
    }

    removeToken(frame, tokenType, stacks = 1) {
        if (!frame.tokens) return 0;

        const existing = frame.tokens.find(t => t.type === tokenType);
        if (!existing) return 0;

        const removed = Math.min(stacks, existing.stacks);
        existing.stacks -= removed;

        if (existing.stacks <= 0) {
            frame.tokens = frame.tokens.filter(t => t.type !== tokenType);
        }

        return removed;
    }

    getTokenStacks(frame, tokenType) {
        if (!frame || !frame.tokens || !Array.isArray(frame.tokens)) return 0;
        const token = frame.tokens.find(t => t.type === tokenType);
        return token ? token.stacks : 0;
    }

    clearTokens(frame) {
        frame.tokens = [];
    }

    processTokenEffects(frame, frameName) {
        if (!frame || !frame.tokens || !Array.isArray(frame.tokens) || frame.tokens.length === 0) return;

        // --- BURN ---
        const burnToken = frame.tokens.find(t => t.type === 'BURN');
        if (burnToken) {
            let totalBurnDamage = 0;
            let stacksRemoved = 0;

            // Roll d6 PER STACK
            for (let i = burnToken.stacks; i > 0; i--) {
                const roll = Math.floor(Math.random() * 6) + 1;
                if (roll >= 4) {
                    totalBurnDamage += 1;
                } else {
                    // Roll <= 3: this stack extinguishes
                    stacksRemoved++;
                }
            }

            // Apply BURN damage
            if (totalBurnDamage > 0) {
                // BURN damage hits random part (auto weighted)
                const targetPart = selectTargetPartWeighted(frame, 'auto');

                // Check for BREACH interaction: BURN damage is amplified by BREACH
                const breachStacks = this.getTokenStacks(frame, 'BREACH');
                const finalBurnDamage = totalBurnDamage + breachStacks;

                CombatUtils.applyDamage(frame, targetPart, finalBurnDamage);

                let logMsg = `  🔥 ${frameName} burns! ${totalBurnDamage} dmg`;
                if (breachStacks > 0) logMsg += ` (+${breachStacks} BREACH)`;
                logMsg += ` → ${PART_NAMES[targetPart] || targetPart}`;

                this.combatLog.push(logMsg); // Add to visible log
                // Assuming we want a specific log type/color, we might push to a structured log if UI supports it, 
                // but here we mainly push to combatLog array which is strings. 
                // If Log.add supports types, we use that too.
            }

            // Remove extinguished stacks
            if (stacksRemoved > 0) {
                this.removeToken(frame, 'BURN', stacksRemoved);
                const remaining = this.getTokenStacks(frame, 'BURN');
                if (remaining === 0) {
                    this.combatLog.push(`  🔥 ${frameName}: flames extinguished.`);
                } else {
                    this.combatLog.push(`  🔥 ${frameName}: ${stacksRemoved} BURN stacks extinguished. [${remaining} remaining]`);
                }
            }
        }

        // Clean up 0 stacks
        frame.tokens = frame.tokens.filter(t => t.stacks > 0);
    }

    // ─── Stance & Targeting setters (locked during combat) ───────────────────

    setStance(stanceId) {
        if (this.active) return; // Locked during combat
        if (!STANCES[stanceId]) return;
        this.stance = stanceId;
    }

    setTargeting(policyId) {
        if (this.active) return; // Locked during combat
        if (!TARGETING_POLICIES[policyId]) return;
        this.targeting = policyId;
    }

    // ─── Enemy cloning ────────────────────────────────────────────────────────

    _cloneEnemy(template) {
        const e = JSON.parse(JSON.stringify(template));

        // Ensure parts exist and each part has an id (UI relies on part.id for :key)
        if (e.parts && typeof e.parts === 'object') {
            for (const [pid, part] of Object.entries(e.parts)) {
                part.id = part.id || pid;
                part.status = part.status || 'operational';
                part.maxHp = part.maxHp ?? part.hp ?? 1;
                part.hp = part.hp ?? part.maxHp;
                part.integrity = part.integrity ?? 1;
            }
        }

        // Normalize combat fields
        e.heat = e.heat ?? 0;
        e.stress = e.stress ?? 0;
        e.tokens = e.tokens ?? [];

        return e;
    }

    // ─── Mission start ────────────────────────────────────────────────────────

    /**
     * Start a combat mission.
     */
    startMission(mission, enemies) {
        this.mission = mission;

        // Deep clone enemies so templates in GameState never get mutated by combat
        this.enemies = (enemies || []).map((t) => this._cloneEnemy(t));

        this.active = true;
        this.turnNumber = 1;
        this.turnTimer = 0;
        this.combatLog = [];
        this.result = null;

        // Reset player frame combat state (but keep structural damage persistent)
        const playerFrame = this.state.player.frame;
        playerFrame.heat = 0;
        playerFrame.stress = playerFrame.stress ?? 0;
        playerFrame.tokens = [];

        // Initialize tokens for enemies if not already
        for (const enemy of this.enemies) {
            enemy.tokens = enemy.tokens || [];
        }

        // Log mission start with active stance
        const stanceDef = STANCES[this.stance] || STANCES.balanced;
        const targetDef = TARGETING_POLICIES[this.targeting] || TARGETING_POLICIES.auto;
        const atkSign = stanceDef.atkMod >= 0 ? '+' : '';
        const defSign = stanceDef.defMod >= 0 ? '+' : '';

        this.combatLog.push(`Deploying frame... Mission: ${mission.name}`);
        this.combatLog.push(`▶ Stance: ${stanceDef.name} (ATK ${atkSign}${Math.round(stanceDef.atkMod * 100)}% / DEF ${defSign}${Math.round(stanceDef.defMod * 100)}%)`);
        this.combatLog.push(`◎ Targeting: ${targetDef.name}`);

        Log.add(`[COMBAT] Deploying frame... Mission: ${mission.name}`, 'combat');
        Log.add(`[COMBAT] ${stanceDef.icon} ${stanceDef.name} | ${targetDef.icon} ${targetDef.name}`, 'combat');

        Events.emit('COMBAT_START', { mission: mission.id });
    }

    // ─── Game loop ────────────────────────────────────────────────────────────

    /**
     * Update combat for one tick.
     */
    update(dt) {
        if (!this.active || this.result) return;

        const TURN_INTERVAL = 2.5; // Seconds per turn
        this.turnTimer += dt;

        if (this.turnTimer >= TURN_INTERVAL) {
            this.resolveTurn();
            this.turnTimer = 0;
        }
    }

    // ─── Turn resolution ──────────────────────────────────────────────────────

    /**
     * Resolve a single logical turn.
     */
    resolveTurn() {
        if (!this.active || this.result) return;

        const playerFrame = this.state.player.frame;

        // Instincts Phase
        this.processManeuvers('turn_start', { unit: playerFrame });

        // Action Phase
        if (this.canAct(playerFrame, 'Your Frame')) {
            this.resolvePlayerAttack();
        }

        // Each enemy attacks
        for (const enemy of this.enemies) {
            if (!CombatUtils.isFrameDestroyed(enemy)) {
                if (enemy.isBoss && enemy.bossPhases) {
                    this._checkBossPhases(enemy);
                }

                if (this.canAct(enemy, enemy.name)) {
                    this.resolveEnemyAttack(enemy);
                }
            }
        }

        // Maintenance Phase
        this.maintenancePhase(playerFrame, true); // true = is player (apply stance heat dissip)
        for (const enemy of this.enemies) this.maintenancePhase(enemy, false);

        // Check End Conditions
        this.checkEndConditions();

        this.turnNumber++;
    }

    resolvePlayerAttack() {
        const playerFrame = this.state.player.frame;

        // Player attacks the first operational enemy
        const target = this.enemies.find((e) => !CombatUtils.isFrameDestroyed(e));
        if (!target) return;

        const hit = this._executeAttack(playerFrame, target, this.targeting, true);
        if (!hit) {
            this.combatLog.push(`YOU missed ${target.name}.`);
        }
    }

    resolveEnemyAttack(enemy) {
        const playerFrame = this.state.player.frame;
        const hit = this._executeAttack(enemy, playerFrame, 'auto', false);
        if (!hit) {
            this.combatLog.push(`${enemy.name} missed YOU.`);
        }
    }

    _checkBossPhases(enemy) {
        if (!enemy.bossPhases) return;

        const currentPhaseIdx = enemy.currentPhase || 1;
        const nextPhase = enemy.bossPhases.find(p => p.phase === currentPhaseIdx + 1);

        if (!nextPhase) return; // No more phases

        let triggered = false;

        // Evaluate trigger conditions
        if (nextPhase.trigger === 'combat_start' && this.turnNumber === 1) triggered = true;

        // HP triggers
        if (nextPhase.trigger.startsWith('hp_below_')) {
            const threshold = parseInt(nextPhase.trigger.split('_')[2], 10) / 100;
            const totalHp = Object.values(enemy.parts || {}).reduce((sum, p) => sum + (p.hp || 0), 0);
            const totalMaxHp = Object.values(enemy.parts || {}).reduce((sum, p) => sum + (p.maxHp || 0), 0);
            if (totalMaxHp > 0 && totalHp / totalMaxHp <= threshold) triggered = true;
        }

        // Torso HP triggers
        if (nextPhase.trigger.startsWith('torso_hp_below_')) {
            const threshold = parseInt(nextPhase.trigger.split('_')[3], 10) / 100;
            const torso = enemy.parts?.torso;
            if (torso && torso.hp / torso.maxHp <= threshold) triggered = true;
        }

        // Heat triggers
        if (nextPhase.trigger.startsWith('heat_above_')) {
            const threshold = parseInt(nextPhase.trigger.split('_')[2], 10);
            if ((enemy.heat || 0) >= threshold) triggered = true;
        }

        if (triggered) {
            enemy.currentPhase = nextPhase.phase;

            // Log phase transition
            this.combatLog.push(`\n⚠ WARNING: ${enemy.name.toUpperCase()} HAS ENTERED PHASE ${nextPhase.phase}: ${nextPhase.name.toUpperCase()} ⚠`);

            // Check for dialogue
            if (enemy.narrative && enemy.narrative.dialogue) {
                const diag = enemy.narrative.dialogue.find(d => d.trigger === nextPhase.trigger);
                if (diag) {
                    this.combatLog.push(`${enemy.name}: "${diag.text}"`);
                }
            }

            // Apply phase modifiers (stack permanently onto attributes)
            if (!enemy.attributes) enemy.attributes = { atk: 0, def: 0 };
            enemy.phaseMods = enemy.phaseMods || { atkMod: 0, evasion: 0, damageMult: 1 };

            if (nextPhase.atkMod) enemy.phaseMods.atkMod += nextPhase.atkMod;
            if (nextPhase.evasion) enemy.phaseMods.evasion += nextPhase.evasion;
            if (nextPhase.damageMult) enemy.phaseMods.damageMult *= nextPhase.damageMult;
        }
    }

    /**
     * Check if a unit can act this turn (handles ERROR token).
     */
    canAct(unit, name) {
        const errorStacks = this.getTokenStacks(unit, 'ERROR');
        if (errorStacks > 0) {
            const roll = Math.floor(Math.random() * 6) + 1;
            // 4+ = Glitch triggers
            if (roll >= 4) {
                const stressDmg = 1;
                unit.stress = (unit.stress || 0) + stressDmg;

                this.removeToken(unit, 'ERROR', 1);

                this.combatLog.push(`⚡ ${name} [ERROR] System Malfunction! Action lost. (+${stressDmg} Stress)`);
                return false;
            }
        }
        return true;
    }

    /**
     * Execute one attack.
     * @param {Object} attacker
     * @param {Object} defender
     * @param {string} policy - targeting policy id
     * @param {boolean} isPlayer - true if attacker is the player
     */
    _executeAttack(attacker, defender, policy, isPlayer) {
        const modifiers = { ...this.activeModifiers };
        const stanceDef = STANCES[this.stance] || STANCES.balanced;

        // ── Stance modifiers ──────────────────────────────────────────────────
        if (isPlayer) {
            // Player attacking: atkMod boosts accuracy
            modifiers.accuracyBonus = (modifiers.accuracyBonus || 0) + Math.round(stanceDef.atkMod * 100);
        } else {
            // Enemy attacking player: defMod makes player harder to hit
            modifiers.accuracyBonus = (modifiers.accuracyBonus || 0) - Math.round(stanceDef.defMod * 100);
        }

        // ── Boss Phase Modifiers ──────────────────────────────────────────────
        if (attacker.phaseMods) {
            modifiers.accuracyBonus = (modifiers.accuracyBonus || 0) + Math.round((attacker.phaseMods.atkMod || 0) * 100);
            modifiers.damageMult = (modifiers.damageMult || 1) * (attacker.phaseMods.damageMult || 1);
        }
        if (defender.phaseMods) {
            modifiers.accuracyBonus = (modifiers.accuracyBonus || 0) - Math.round((defender.phaseMods.evasion || 0) * 100);
        }

        // ── Heat & Stress penalties (§7.1, §7.2) ─────────────────────────────
        const chassis = isPlayer ? this.state.items[attacker.chassisId] : null;
        const heatCap = chassis ? chassis.heatCap : 100;

        if ((attacker.heat || 0) >= heatCap * 0.76) {
            modifiers.accuracyBonus = (modifiers.accuracyBonus || 0) - 15;
        }

        if ((attacker.stress || 0) >= 51) {
            modifiers.accuracyBonus = (modifiers.accuracyBonus || 0) - 10;
        }

        // ── Token Effects: SLOW (Accuracy/Evasion) ────────────────────────────
        const attackerSlow = this.getTokenStacks(attacker, 'SLOW');
        const defenderSlow = this.getTokenStacks(defender, 'SLOW');

        if (attackerSlow > 0) {
            // Harder to aim/maneuver
            modifiers.accuracyBonus = (modifiers.accuracyBonus || 0) - (10 * attackerSlow);
        }
        if (defenderSlow > 0) {
            // Easier to hit
            modifiers.accuracyBonus = (modifiers.accuracyBonus || 0) + (10 * defenderSlow);
        }

        const targetPercent = Math.max(5, Math.min(95,
            CombatUtils.calculateTargetPercent(attacker, defender, modifiers)
        ));
        const result = rollD100(targetPercent);

        if (result.success) {
            // ── Select target part using weighted policy ───────────────────────
            const partId = selectTargetPartWeighted(defender, isPlayer ? policy : 'auto');
            const partName = PART_NAMES[partId] || partId.toUpperCase();

            let damage = 20;
            if (result.critical) damage *= 2;

            // ── Token Effects: TARGET_LOCK (Bonus Dice) ──────────────────────
            let bonusDiceCount = 1; // Base
            if (this.getTokenStacks(defender, 'TARGET_LOCK') > 0) {
                bonusDiceCount += 1;
                this.combatLog.push(`${TOKEN_DEFS.TARGET_LOCK.icon} Target Locked! +1 Bonus Die`);
            }

            const bonusDice = rollBonusPool(bonusDiceCount);
            const bonusResults = resolveBonusDice(bonusDice);
            if (bonusResults.directHits > 0) {
                damage += bonusResults.bonusAvaria * 10;
                defender.stress = (defender.stress || 0) + bonusResults.bonusStress;
            }

            // ── Stance damage modifier (atkMod also scales damage) ────────────
            if (isPlayer) {
                damage = Math.round(damage * (1 + stanceDef.atkMod));
            }

            damage *= modifiers.damageMult || 1;

            // ── BREACH Damage Amplification (§8.1) ────────────────────────────
            const breachStacks = this.getTokenStacks(defender, 'BREACH');
            if (breachStacks > 0) {
                damage += breachStacks;
            }

            // ── Token Effects: SUPPRESS (Damage Reduction) ────────────────────
            const suppressStacks = this.getTokenStacks(attacker, 'SUPPRESS');
            if (suppressStacks > 0) {
                damage = Math.max(1, damage - suppressStacks); // Minimum 1 damage? Or 0? Let's say 1 for now or calculate raw.
                // Log suppression? Maybe too verbose.
            }

            const dmgResult = CombatUtils.applyDamage(defender, partId, damage);

            // ── Build log line ─────────────────────────────────────────────────
            const policyDef = TARGETING_POLICIES[isPlayer ? this.targeting : 'auto'];
            const critTag = result.critical ? ' [CRITICAL!]' : '';
            const breachTag = breachStacks > 0 ? ` (+${breachStacks} 🔓)` : '';
            const destroyTag = dmgResult.destroyed ? ` ⚠ ${partName} DESTROYED!` : (dmgResult.integrityLoss ? ` ↓ ${partName} integrity lost!` : '');
            const attName = isPlayer ? 'YOU' : attacker.name;
            const defName = isPlayer ? defender.name : 'YOU';

            this.combatLog.push(
                `${attName} → ${partName} on ${defName} [${Math.round(damage)} dmg]${critTag}${breachTag}${destroyTag}`
            );

            // ── Apply Tokens (BREACH / BURN) ──────────────────────────────────

            // 1. Player Critical Hit -> BREACH
            if (isPlayer && result.critical) {
                const applied = this.applyToken(defender, 'BREACH', 1);
                if (applied > 0) {
                    this.combatLog.push(`🔓 BREACH! Armor compromised. [${this.getTokenStacks(defender, 'BREACH')} stacks]`);
                }
            }

            // 2. Enemy TokenOnHit
            if (!isPlayer && attacker.tokenOnHit) {
                for (const { type, chance, stacks } of attacker.tokenOnHit) {
                    if (Math.random() < chance) {
                        const applied = this.applyToken(defender, type, stacks || 1);
                        if (applied > 0) {
                            const def = TOKEN_DEFS[type];
                            this.combatLog.push(`${def.icon} ${attacker.name} applies ${def.name}! [${this.getTokenStacks(defender, type)} stacks]`);
                        }
                    }
                }
            }

            if (dmgResult.integrityLoss || dmgResult.destroyed) {
                this.processManeuvers('on_hit_received', { unit: defender, attacker });
            }

            attacker.heat = Math.min(heatCap, (attacker.heat || 0) + 10 * (chassis ? chassis.heatGenMod : 1));
            this.activeModifiers = { damageMult: 1, accuracyBonus: 0 };
            return true;
        }

        const chassisMiss = isPlayer ? this.state.items[attacker.chassisId] : null;
        const heatCapMiss = chassisMiss ? chassisMiss.heatCap : 100;
        attacker.heat = Math.min(heatCapMiss, (attacker.heat || 0) + 5 * (chassisMiss ? chassisMiss.heatGenMod : 1));
        this.activeModifiers = { damageMult: 1, accuracyBonus: 0 };
        return false;
    }

    // ─── Maintenance phase ────────────────────────────────────────────────────

    /**
     * @param {Object} unit
     * @param {boolean} isPlayer - if true, apply stance heatDissipMod
     */
    maintenancePhase(unit, isPlayer = false) {
        // Process Tokens (BURN, etc) BEFORE heat processing
        const name = isPlayer ? 'Your Frame' : unit.name;
        this.processTokenEffects(unit, name);

        const BASE_HEAT_DISSIP = 15;
        const enr = isPlayer ? (this.state.player.frame.attributes?.enr || 0) : 50;
        const enrMod = 1 + (enr / 100);

        let stanceMod = 1;
        let chassisDissipMod = 1;
        let stressInc = 0.5;

        if (isPlayer) {
            const stanceDef = STANCES[this.stance] || STANCES.balanced;
            stanceMod = 1 + (stanceDef.heatDissipMod || 0);

            const chassis = this.state.items[this.state.player.frame.chassisId];
            if (chassis) {
                chassisDissipMod = chassis.heatDissipMod || 1;
                stressInc = chassis.stressPerTurn || 0.5;
            }
        }

        const finalHeatDissip = Math.round(BASE_HEAT_DISSIP * enrMod * stanceMod * chassisDissipMod);
        unit.heat = Math.max(0, (unit.heat || 0) - finalHeatDissip);

        // Stress increases slightly every turn unless specialized recovery exists
        unit.stress = (unit.stress || 0) + stressInc;

        if (unit.maneuvers) {
            unit.maneuvers.forEach((m) => {
                if (m.cooldown > 0) m.cooldown--;
            });
        }
    }

    // ─── End conditions ───────────────────────────────────────────────────────

    checkEndConditions() {
        const playerFrame = this.state.player.frame;

        // --- DEFEAT CHECK ---
        const structuralFailure = CombatUtils.isFrameDestroyed(playerFrame);
        const chassis = this.state.items[playerFrame.chassisId];
        const heatCap = chassis ? chassis.heatCap : 100;

        const heatShutdown = (playerFrame.heat || 0) >= heatCap;
        const stressCollapse = (playerFrame.stress || 0) >= 100;

        if (structuralFailure || heatShutdown || stressCollapse) {
            let reason = 'DEFEAT';
            if (heatShutdown) {
                reason = 'HEAT SHUTDOWN';
                this.combatLog.push('⚠ CRITICAL: Reactor emergency shutdown! Cooling system failed.');
            } else if (stressCollapse) {
                reason = 'STRESS COLLAPSE';
                this.combatLog.push('⚠ CRITICAL: Neural link severed! Pilot feedback saturation.');
            }

            this.clearTokens(playerFrame);
            this.endCombat('defeat', reason);
            return;
        }

        // --- VICTORY CHECK ---
        const allEnemiesDestroyed = this.enemies.every((e) => {
            const structural = CombatUtils.isFrameDestroyed(e);
            const thermal = (e.heat || 0) >= 100;
            const neural = (e.stress || 0) >= 100;
            return structural || thermal || neural;
        });

        if (allEnemiesDestroyed) {
            // Find specific reason for last enemy destroyed? Or just victory
            this.clearTokens(playerFrame);
            this.endCombat('victory');
        }
    }

    endCombat(result, reason = null) {
        if (this.result) return; // prevent double-end

        this.result = result;
        this.active = false;

        this.combatLog.push(`── Combat Ended: ${result.toUpperCase()} ${reason ? `(${reason})` : ''} ──`);
        Log.add(`[COMBAT] Combat Ended: ${result.toUpperCase()}${reason ? ` - ${reason}` : ''}`, 'combat');

        if (result === 'victory') {
            const rewards = this.mission.rewards || { glory: 1, scrap: 10 };
            this.state.award(rewards);

            if ((this.mission.completed || 0) === 0 && this.mission.firstClearBonus) {
                this.state.award(this.mission.firstClearBonus);
            }
            this.mission.completed = (this.mission.completed || 0) + 1;

            // Phase 4: Salvage & Degradation
            this._processSalvage();
            this._degradePlayerParts();
        } else {
            const failRewards = this.mission.failRewards || { scrap: 2 };
            this.state.award(failRewards);
        }

        Events.emit('COMBAT_END', { result, reason, mission: this.mission.id });
    }

    _processSalvage() {
        const salvaged = [];
        this.enemies.forEach(enemy => {
            if (CombatUtils.isFrameDestroyed(enemy) || (enemy.heat || 0) >= 100 || (enemy.stress || 0) >= 100) {
                if (enemy.drops) {
                    enemy.drops.forEach(drop => {
                        if (Math.random() < drop.chance) {
                            const partTemplate = this.state.items[drop.id];
                            if (partTemplate) {
                                const newPart = {
                                    id: `${drop.id}_salvage_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
                                    templateId: drop.id,
                                    name: partTemplate.name,
                                    type: 'frame_part',
                                    slot: partTemplate.slot,
                                    condition: Math.round((0.3 + Math.random() * 0.4) * 100) / 100,
                                    hp: partTemplate.hp,
                                    maxHp: partTemplate.maxHp,
                                    integrity: partTemplate.integrity,
                                    armor: partTemplate.armor,
                                    origin: partTemplate.origin
                                };
                                this.state.player.partsInventory.push(newPart);
                                salvaged.push(partTemplate.name);
                            }
                        }
                    });
                }
            }
        });

        if (salvaged.length > 0) {
            this.combatLog.push(`🛠 SALVAGE RECOVERED: ${salvaged.join(', ')}`);
        }
    }

    _degradePlayerParts() {
        const frame = this.state.player.frame;
        for (const slot in frame.parts) {
            const part = frame.parts[slot];
            if (part && part.status !== 'destroyed') {
                part.condition = Math.max(0, Math.round(((part.condition || 1.0) - 0.05) * 100) / 100);
            }
        }
        // Force stat recalculation in game logic if needed
    }

    // ─── Serialization ────────────────────────────────────────────────────────

    toJSON() {
        return {
            active: this.active,
            missionId: this.mission?.id || null,
            enemies: this.enemies,
            turnNumber: this.turnNumber,
            turnTimer: this.turnTimer,
            combatLog: this.combatLog,
            result: this.result,
            stance: this.stance,
            targeting: this.targeting,
            equippedManeuvers: this.equippedManeuvers,
            playerTokens: this.state.player.frame.tokens || [],
        };
    }

    fromJSON(data) {
        if (!data) return;
        this.active = !!data.active;
        this.mission = this.state.get(data.missionId);
        this.enemies = (data.enemies || []).map((e) => this._cloneEnemy(e));
        this.turnNumber = data.turnNumber || 1;
        this.turnTimer = data.turnTimer || 0;
        this.combatLog = data.combatLog || [];
        this.result = data.result || null;
        this.stance = data.stance || 'balanced';
        this.targeting = data.targeting || 'auto';
        this.equippedManeuvers = data.equippedManeuvers || [];

        if (data.playerTokens) {
            this.state.player.frame.tokens = data.playerTokens;
        }
        // Enemies tokens are restored via this.enemies map (since tokens are part of enemy object)
    }

    // ─── Maneuver system ──────────────────────────────────────────────────────

    setManeuvers(ids) {
        this.equippedManeuvers = (ids || []).slice(0, 3);
    }

    processManeuvers(phase, context) {
        // Safe check for items map
        if (!this.state.items) return false;

        for (const id of this.equippedManeuvers) {
            const mnvr = this.state.items[id];
            if (!mnvr || mnvr.owned === 0) continue;

            if (phase === 'turn_start' && mnvr.trigger === 'turn_start') {
                this._executeInstinct(mnvr, context);
            }
            if (phase === 'on_hit_received' && mnvr.trigger === 'on_hit_received') {
                this._executeReaction(mnvr, context);
            }
            if (phase === 'action' && mnvr.trigger === 'action_replace') {
                return this._executeManeuver(mnvr, context);
            }
        }
        return false;
    }

    _executeInstinct(mnvr, { unit }) {
        if (mnvr.triggerCondition === 'stress>60' && (unit.stress || 0) < 60) return;

        this.combatLog.push(`⚡ Instinct: ${mnvr.name}`);
        if (mnvr.effect?.atkMod) this.activeModifiers.damageMult += mnvr.effect.atkMod;
        if (mnvr.effect?.accuracyMod) this.activeModifiers.accuracyBonus += mnvr.effect.accuracyMod * 100;
    }

    _executeReaction(mnvr, { unit, attacker }) {
        this.combatLog.push(`↩ Reaction: ${mnvr.name}`);

        if (mnvr.effect?.counterAttack && attacker) {
            const dmg = 10 * (mnvr.effect.damageMod || 1);
            CombatUtils.applyDamage(attacker, 'torso', dmg, true);
        }
    }

    _executeManeuver(mnvr, { unit, target }) {
        this.combatLog.push(`▶ Maneuver: ${mnvr.name}`);
    }
}